create definer = root@localhost view total_donations as
select count(0) AS `count`
from `blood_donation`.`donation`;

