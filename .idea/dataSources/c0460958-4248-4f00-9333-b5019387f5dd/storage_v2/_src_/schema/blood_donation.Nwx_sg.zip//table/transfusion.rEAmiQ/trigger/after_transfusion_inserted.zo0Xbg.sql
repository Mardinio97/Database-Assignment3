create definer = root@localhost trigger after_transfusion_inserted
    after insert
    on transfusion
    for each row
BEGIN
    declare donor_group varchar(50);
    declare item_coun2t int;

    set donor_group = (select blood_group
                       from donor
                                join transfusion t on donor.donor_id = t.blood_donor_id
                       where transfusion_id =
                             (SELECT transfusion_id FROM transfusion ORDER BY transfusion_id DESC LIMIT 1));

    set item_coun2t = (select quantity from blood where blood_group = donor_group);

    if (donor_group = 'A') then
        update blood set quantity = item_coun2t - 1 where id = 1;
    elseif (donor_group = 'B') then
        update blood set quantity = item_coun2t - 1 where id = 2;
    elseif (donor_group = 'AB') then
        update blood set quantity = item_coun2t - 1 where id = 3;
    elseif (donor_group = 'O') then
        update blood set quantity = item_coun2t - 1 where id = 4;
    end if;
END;

