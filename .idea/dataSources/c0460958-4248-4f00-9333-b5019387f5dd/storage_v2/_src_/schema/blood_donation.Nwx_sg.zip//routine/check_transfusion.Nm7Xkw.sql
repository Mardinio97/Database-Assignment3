create
    definer = root@localhost procedure check_transfusion(IN tran int(20))
BEGIN


    select donor_id,
           name,
           mob_number,
           blood_group,
           t.transfusion_id,
           t.receiver_id,
           t.transfusion_Bag_Id,
           bd.donation_number
    from donor
             join transfusion t on donor.donor_id = t.blood_donor_id
             join blood_donation bd on t.transfusion_Bag_Id = bd.blood_Bag_Id
             join transfusion t2 on donor.donor_id = t2.blood_donor_id
    where t2.transfusion_id = tran;


END;

