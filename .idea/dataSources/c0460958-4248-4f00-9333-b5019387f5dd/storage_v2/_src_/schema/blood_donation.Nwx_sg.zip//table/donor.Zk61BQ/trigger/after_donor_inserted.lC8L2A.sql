create definer = root@localhost trigger after_donor_inserted
    after insert
    on donor
    for each row
BEGIN
    declare item_count int;
    set item_count = (select quantity from blood where blood.blood_group = NEW.blood_group);

    if (NEW.blood_group = 'A') then
        update blood set quantity = item_count + 1 where id = 1;
    elseif (NEW.blood_group = 'B') then
        update blood set quantity = item_count + 1 where id = 2;
    elseif (NEW.blood_group = 'AB') then
        update blood set quantity = item_count + 1 where id = 3;
    elseif (NEW.blood_group = 'O') then
        update blood set quantity = item_count + 1 where id = 4;
    end if;


END;

