create
    definer = root@localhost procedure add_donation(IN donor_mob_number varchar(250), IN amount int(20),
                                                    IN stat int(10))
BEGIN
    DECLARE d_id INTEGER;
    DECLARE bag_id INTEGER;
    select donor_id into d_id from donor where mob_number = donor_mob_number;

    insert into donation (donor_id, donor_mob_number, receivedAt, amount_Liter, status)
    values (d_id, donor_mob_number, now(), amount, stat);

    insert into blood_donation(donation_number) value (last_insert_id());

    insert into blood_log(donor_id, log_Bag_Id)
    VALUES (d_id, (SELECT blood_Bag_Id FROM blood_donation ORDER BY blood_Bag_Id DESC LIMIT 1));


END;

