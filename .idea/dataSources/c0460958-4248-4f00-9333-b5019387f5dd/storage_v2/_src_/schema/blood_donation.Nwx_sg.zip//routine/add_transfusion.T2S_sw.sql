create
    definer = root@localhost procedure add_transfusion(IN donationSerialNumber int(20))
BEGIN
    DECLARE d_id INTEGER;
    DECLARE bag_id INTEGER;
    DECLARE reciver_rand DECIMAL;
    set reciver_rand = (SELECT CAST((SELECT RAND() * (10000 - 1000) + 10000) AS decimal));
    select d.donor_id
    into d_id
    from blood_donation
             join donation d on d.id = blood_donation.donation_number
    where donation_number = donationSerialNumber;

    select blood_Bag_Id
    into bag_id
    from blood_donation
             join donation d on d.id = blood_donation.donation_number
    where donation_number = donationSerialNumber;

    insert into transfusion(receiver_id, transfusion_Bag_Id, blood_donor_id) VALUES (reciver_rand, bag_id, d_id);

    insert into transfusion_log(stamp_time, blood_id, transfusion_id) VALUES (now(), d_id, last_insert_id());

    select reciver_rand;


END;

