create
    definer = root@localhost procedure check_donations_for_user(IN donorMobNumber varchar(250))
BEGIN

    select d.name, d.city, d.blood_group, count(*) as number_of_donations
    FROM donation
             join donor d on donation.donor_id = d.donor_id

    where donor_mob_number = donorMobNumber
    GROUP BY d.donor_id;

END;

