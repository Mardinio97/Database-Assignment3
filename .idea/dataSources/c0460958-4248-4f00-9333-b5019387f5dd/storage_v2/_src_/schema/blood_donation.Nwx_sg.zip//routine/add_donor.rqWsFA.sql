create
    definer = root@localhost procedure add_donor(IN first varchar(250), IN last varchar(250), IN ema varchar(250),
                                                 IN mob varchar(250), IN gro varchar(250))
BEGIN


    insert into donor(name, city, email, mob_number, blood_group) VALUES (first,last,ema,mob,gro);
    select last_insert_id() as donorID;



END;

